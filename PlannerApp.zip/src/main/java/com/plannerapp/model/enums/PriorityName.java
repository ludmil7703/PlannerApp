package com.plannerapp.model.enums;

public enum PriorityName {
    URGENT, IMPORTANT, LOW;

}
